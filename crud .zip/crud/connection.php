<?php 
	
	$db = mysqli_connect('localhost', 'root', '', 'php_crud');

	// initialize variables
	$name = "";
	$email = "";
	$id = 0;
	$edit_state =false;

    

     // if save button is clicked

	if (isset($_POST['save'])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
        
        $query ="INSERT INTO php_crud1 (name, email) VALUES ('$name','$email')";
        mysqli_query($db,$query);
        // redirect to index page after inserting
        header('location: index.php');
	}
    
    //update records
     if (isset($_POST['update']))
     {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$id = $_POST['id'];

		mysqli_query($db, "UPDATE php_crud1 SET name='$name', email='$email' WHERE id= $id");
		header('location: index.php');
	}

	//delete records
    if (isset($_GET['delete'])){
    	$id = $_GET['delete'];
    	mysqli_query($db, "DELETE FROM php_crud1 WHERE id = '$id'");
    	header('location:index.php');
    }


	//retrive records

	$results = mysqli_query($db, "SELECT * FROM php_crud1");


	?>