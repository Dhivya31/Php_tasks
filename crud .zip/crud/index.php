<?php  include('connection.php');
  
    //fetch the record to be update
     if(isset($_GET['edit'])){
      $id = $_GET['edit'];
      $edit_state = true;
      $res = mysqli_query($db, "SELECT * FROM php_crud1 WHERE id=$id");
      $record = mysqli_fetch_array($res);
      $name = $record['name'];
      $email =$record['email'];
      $id =$record['id'];

     }

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>PHP CRUD</title>
     <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
</head>

<body style="margin-top: 3em;">

  <div class="container">
    <div class="row">


  
        <div class="col-6">
          <h2 class="">PHP CRUD</h2>
  <br>

	<form method="post" action="connection.php" >
        <div class="form-group">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
		<div class="input-group">
			<label>Name:</label> 
			<input type="text" id="fname" name="name" value="<?php echo $name; ?>">
		</div> 
  </div>
  <br>
  <div class="form-group">
		<div class="input-group">
			<label>Email:</label> 
			<input type="text" name="email" value="<?php echo $email; ?>">
		</div>

  </div>
  <br>
		<div class="input-group">
      <?php if ($edit_state == false): ?>

     <button class="btn btn-primary" type="submit" name="save" >Save</button>
    <?php else:?>
           <button class="btn btn-success" type="submit" name="update" >Update</button>
     <?php endif ?>
		</div><br>
	</form>
</div>


      <div class="col-6">
     <table class="table table-bordered">
     	<thead>
     		<tr>
     			<th>Name</th>
     			<th>email</th>
     			<th colspan="2">Action</th>
     		</tr>
     	</thead>

     	<tbody>
        <?php 
          while($row = mysqli_fetch_array($results)) { ?>


          <tr>
               <td><?php echo $row['name']; ?></td>
               <td><?php echo $row['email']; ?></td>
                <td>
                    <a href="index.php?edit=<?php echo $row['id']; ?>" class="btn btn-info" >Edit</a>
               
               
                  <a href="index.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a>
             </td>  
          </tr>     
     <?php } ?>
     		
     	</tbody>


     </table>
     </div>
     </div>
</div>


	
</body>
</html>